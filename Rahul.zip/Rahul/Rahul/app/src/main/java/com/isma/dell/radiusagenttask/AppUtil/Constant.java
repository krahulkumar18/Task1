package com.isma.dell.radiusagenttask.AppUtil;

public class Constant {
    public static final String FACILITY_ID="FacilityId";
    public static final String OPTION_ID="OptionId";
    public static final String PROPERTY_NAME="PropertyName";
    public static final String NO_OF_ROOMS="NoOfRooms";
    public static final String OTHER_FACILITY="OtherFacility";
}
